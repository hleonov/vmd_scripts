#!/usr/bin/perl -w

#init to opposite very small numbers
$max = -100;
$average = 0;
foreach my $file (`ls -1 *.pdo`) {
	chomp $file;
	open (PDO,"$file") || die "Cannot open $file\n";
	while (<PDO>) {
		if (m/(\d+.\d+)\s+(-?\d+.\d+)/) {
			$shift = abs($2);
			$average += $shift;
			push (@list, $shift);
			if ($max < $shift) {
				$max = $shift;
			}
		}
	}
	close(PDO);
}
#multiply all by 10 so units are in Angstrom
$max = $max*10;
$average = $average*10 / ($#list+1);
$std_dev = 10*std(\@list, $average);
print "max: $max\n";
print "Average: $average\n";
print "Std: $std_dev\n";

sub std {
	my @arr = @{$_[0]};
	my $avg = $_[1];
	my $std = 0;
	foreach $elem (@arr) {
		$std += ($elem-$avg)**2;
	}
	$std /= ($#arr+1);
	return sqrt($std);
}
