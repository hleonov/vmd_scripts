
require "/Users/hleonov/Desktop/shy_perl_stuff.pl";

@list = &recurse(".");
foreach $i (@list) {
  print "$i\n";
}
