#!/usr/bin/perl -w
# This script should eventually run all the analysis scripts possible.

$param_file = shift || die "Usage: perl $0 <param-file>\n";

undef(%param);
$vmdt = '/Applications/VMD\ 1.8.6.app/Contents/MacOS/startup.command -dispdev text';

&read_param($param_file);

&rmsd if ($param{'rmsd'} == 1);
&water if ($param{'water'} == 1);
&res_dist if ($param{'resdist'} == 1);
&dihedrals if ($param{'dihedrals'} == 1);

sub read_param {
	open(PAR, $_[0]) || die "Cannot open $_[0]\n$!";
	while (<PAR>) {
		next if (m/^#/ || m/^\s*$/);	#skip comments and empty lines
		s/\s//g;
		@parts = split(/=/);
		next if ($#parts<1); #skip lines without =
		$param{$parts[0]} = $parts[1];
		print "param{$parts[0]} = $parts[1]\n";
	}
	close(PAR);
	my $n = length($param{'trj'});
	$param{'trjtype'} = substr($param{'trj'},$n-3,3);
}

sub contacts {
	
}

sub dihedrals {
	my $i=1;
	while (defined $param{"dhdlist$i"}) {
		my $listfile = $param{"dhdlist$i"};
		my $name = $param{"dhdname$i"};
		my $com = "$vmdt -e ~/vmd_scripts/compute_dihedrals.tcl -args $param{'pr'} $listfile $name\_dihedrals.txt $param{'trjtype'} $param{'dhdskip'} $param{'trj'}";
		system($com) == 0 || die "Residue dihedrals Error: Problem with computing dihedrals for $name\n";
		$i++;
	}
}

sub res_dist {
	my $i=1;
	while (defined $param{"dist$i"}) {
			$param{"dist$i"} =~ s/\;/ /g;
#			print $param{"dist$i"}."\n";
			my $name = $param{"dname$i"};
			$com_d = "$vmdt -e ~/vmd_scripts/residue_dist.tcl -args $param{'pr'} $param{'trjtype'} $param{'distskip'} $param{'trj'} $name\_dist.txt $name\_min_dist.txt ".$param{"dist$i"};
#			print $com_d."\n";
			system($com_d) == 0 || die "Residue dist Error: Problem with computing residue distances for $name\n";
			$i++;
	}
}

sub water {
	my $com1 = "$vmdt -e ~/vmd_scripts/water_connectivity.tcl -args $param{'pr'} $param{'trj'} connect_$param{'connect_rad'} $param{'res'} $param{'conskip'} $param{'connect_rad'} $param{'trjtype'}";
	my $com2 = "$vmdt -e ~/vmd_scripts/analyze_waters_fragment.tcl -args $param{'pr'} $param{'trj'} $param{'trjtype'} results $param{'slices'} $param{'range'} $param{'cyl'} $param{'frames'}";
 	my $com3 = "$vmdt -e ~/vmd_scripts/water.tcl -args $param{'slices'} $param{'pr'} $param{'trj'} $param{'conskip'} $param{'trjtype'} $param{'cyl'}";

	system($com1) == 0 || die "Water proc: Connectivity Error\n";	
	system($com2) == 0 || die "Water proc: Excel histogram Error\n";	
	system($com3) == 0 || die "Water proc: Cumulative histogram Error\n";	
}

sub rmsd {
	#rmsd from after-EM structure
	my $com1 = "printf \"3\n3\n\" | g_rms -s $param{'prtpr'} -f $param{'trj'} -o rmsd_md_from_em.xvg";
    #rmsd from after-PR structure
    my $com2 = "printf \"3\n3\n\" | g_rms -s $param{'mdtpr'} -f $param{'trj'} -o rmsd_md.xvg";
	
	system($com1) == 0 || die "RMSD Error: cannot exec RMSD from EM structure\n";
	system($com2) == 0 || die "RMSD Error: cannot exec RMSD from PR structure\n";
	
	#rmsd of seperate helices - first define helices 
	@hx = split (/\;/, $param{'helices'});
	$hx_def = "";
	for (my $i=0; $i<=$#hx; $i++) {
		$hx_def .= "r $hx[$i]\n";			#including sidechains
		$hx_def_ca .= "r $hx[$i] & 3\n";	#define only CA of each helix
		$groups[$i] = "r_$hx[$i]";
		$groups_ca[$i] = "r_$hx[$i]\_\&_C-alpha";
		$hx_out[$i] = "rmsd_h$i.xvg";		#define output file
		$hx_out_ca[$i] = "rmsd_ca_h$i.xvg";	
	}
	print "my helices: $hx_def\n";
	my $ndx_com = "printf \"$hx_def $hx_def_ca q\n\" | make_ndx -f $param{'em'} -n $param{'index'} -o system2.ndx";
	system($ndx_com) == 0 || die "RMSD Error: cannot exec make_ndx\n";
	
	for (my $i=0; $i<=$#hx; $i++) {
		$h_com[$i] = "printf \"$groups[$i]\n$groups[$i]\n\" | g_rms -n system2.ndx -s $param{'mdtpr'} -f $param{'trj'} -o $hx_out[$i]";	
		$h_com_ca[$i] = "printf \"$groups_ca[$i]\n$groups_ca[$i]\n\" | g_rms -n system2.ndx -s $param{'mdtpr'} -f $param{'trj'} -o $hx_out_ca[$i]";	
		system($h_com[$i]) == 0 || die "RMSD Error: cannot exec RMSD for helix $i\n";
		system($h_com_ca[$i]) == 0 || die "RMSD Error: cannot exec RMSD for ca-helix $i\n";
	}
}
